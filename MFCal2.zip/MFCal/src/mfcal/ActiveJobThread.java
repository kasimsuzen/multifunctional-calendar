/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mfcal;

import java.net.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;

/**
 *  Bu sinif, uygulama acildigi zaman
 *  yapilmasi gereken bir aktif gorev var ise, 
 *  bu aktif gorev icin bir ip ve file path alir.
 *  Arka planda bir thread kullanarak
 *  bu aktif gorevi yani verilen dosyayi verilen ip ye gonderir.
 * @author mutlu koktemir & osman suzer
 */
public class ActiveJobThread implements Runnable{
    
    private Thread thread;
    private String ip;
    private String filePath;
    
    private String username;
    private String password;
    
    /**
     *  Thread'i baslatir.
     * @param ip  ip = 127.0.0.1:13267   ÅŸeklinde bir hostname bir de portname iÃ§ermeli (ftp server adresi iÃ§in)
     *  eÄŸer ip https://127.0.0.1:13267 ÅŸeklinde alÄ±nmÄ±ÅŸsa URI objesine direkt ip yi gÃ¶ndermelisin
     * @param filepath  gÃ¶nderilecek olan dosya
     */
    public ActiveJobThread(String ip, String filepath)
    {
        this.ip = ip;
        filePath = filepath;
        
        this.username = "client";
        this.password = "client";
        
        thread = new Thread(this,"other");
        thread.start();
        
    }
    
    public ActiveJobThread(String ip, String filepath, String username, String password)
    {
        this.ip = ip;
        filePath = filepath;
        this.username = username;
        this.password = password;
        thread = new Thread(this,"other");
        thread.start();
    }
    
    @Override
    public void run() {
        
        try {
        	
            URI uri = new URI("xxx://" + ip);
            String server = uri.getHost();
            int port = uri.getPort();
            
            FTPClient ftpClient = new FTPClient();
            try {
                ftpClient.connect(server, port);
                ftpClient.login(this.username, this.password);
                ftpClient.enterLocalPassiveMode();
                ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
                
                File myfile = new File(this.filePath);
                InputStream inputStream = new FileInputStream(myfile);
                
                System.out.println("Start uploading file : " + myfile.getName());
                OutputStream outputStream = ftpClient.storeFileStream(myfile.getName());
                byte[] bytesIn = new byte[4096];
                int read = 0;
                
                while ((read = inputStream.read(bytesIn)) != -1) {
                    outputStream.write(bytesIn, 0, read);
                }
                
                inputStream.close();
                outputStream.close();

                boolean completed = ftpClient.completePendingCommand();
                if (completed) {
                    System.out.printf("The file %s is uploaded successfully.\n", myfile.getName());
                }
                
                ftpClient.logout();
                ftpClient.disconnect();
                
            } catch (IOException ex) {
                System.out.println("Error: " + ex.getMessage());
                ex.printStackTrace();
            } finally {
                if (ftpClient.isConnected()) {
                    try {
                        ftpClient.logout();
                        ftpClient.disconnect();
                    } catch (IOException ex) {
                        Logger.getLogger(ActiveJobThread.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }catch (URISyntaxException ex) {
            Logger.getLogger(ActiveJobThread.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
        
}

